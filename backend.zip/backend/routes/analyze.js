const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { callWhisperOpenAI, callWhisperHF, callLLMAnalysis } = require('../services/llm');

const upload = multer({ dest: path.join(__dirname, '..', 'uploads/') });

const PROMPT_TEMPLATE = (transcript, languageHint) => `
You are an empathetic medical assistant. Based on the patient's description below, do all of the following:
1) Provide 3 likely non-diagnostic possible conditions (ranked, brief explanation for each).
2) Provide immediate home-care / first-aid steps (simple steps, safe).
3) State whether this is an emergency and list red-flag signs requiring urgent help.
4) Give suggestions for next steps (e.g., see primary care, teleconsult, tests).
5) Provide short, simple-language (<= 30 words) summary in the patient's language if languageHint is provided.
6) Provide credible references (like WHO, CDC, or Indian govt guidance) if relevant.

Patient transcript:
"${transcript}"
Language hint: ${languageHint || 'unknown'}

Return the answer as valid JSON with keys:
{ "conditions": [{ "name": "...", "confidence": "...", "explanation": "..." }], "firstAid": "...", "urgency": "low|moderate|high|emergency", "redFlags": ["..."], "nextSteps": ["..."], "shortSummary": "..." , "references": ["..."] }
`;

router.post('/analyze', upload.single('audio'), async (req,res) => {
  try {
    const textInput = req.body.text;
    const language = req.body.language || '';
    let transcript = textInput;

    if(req.file){
      const filePath = req.file.path;
      try {
        if(process.env.OPENAI_API_KEY) {
          transcript = await callWhisperOpenAI(filePath);
        } else if(process.env.HUGGINGFACE_API_KEY) {
          transcript = await callWhisperHF(filePath);
        } else {
          throw new Error('No transcription provider configured. Add OPENAI_API_KEY or HUGGINGFACE_API_KEY to backend/.env');
        }
      } finally {
        try { fs.unlinkSync(filePath); } catch(e){}
      }
    }

    if(!transcript || transcript.trim() === '') return res.status(400).json({ error:'No transcript produced' });

    const prompt = PROMPT_TEMPLATE(transcript, language);
    const llmResponse = await callLLMAnalysis(prompt);

    let parsed;
    if(typeof llmResponse === 'string'){
      try { parsed = JSON.parse(llmResponse); }
      catch(e){
        parsed = { raw: llmResponse };
      }
    } else parsed = llmResponse;

    return res.json({ ok:true, transcript, analysis: parsed });
  } catch(err){
    console.error('Analyze error', err);
    return res.status(500).json({ ok:false, error: err.message });
  }
});

module.exports = router;
