// Simple seed script to populate Providers and a User
const mongoose = require('mongoose');
require('dotenv').config();
const User = require('./models/User');
const Provider = require('./models/Provider');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/healthbridge';

async function seed(){
  await mongoose.connect(MONGO);
  await User.deleteMany({});
  await Provider.deleteMany({});

  await User.create({
    name: 'Priyanshu Tonk',
    email: 'priyanshutonkmp@gmail.com',
    location: 'New Delhi',
    emergencyContact: '+91 98765 43210'
  });

  const providers = [
    { name:'Teladoc India', type:'Telemedicine', address:'Online', phone:'1800-XXX', languages:['english','hindi'], hours:'24/7' },
    { name:'MedPlus Pharmacy', type:'Pharmacy', address:'Hyderabad, Telangana', phone:'+91-40-XXXX', languages:['telugu','hindi','english'], hours:'7AM-11PM' },
    { name:'Dr. Rajesh Kumar', type:'Doctor', address:'Delhi Medical Center, New Delhi', phone:'+91-11-XXXX', languages:['hindi','english','punjabi'], hours:'Mon-Sat 9AM-6PM' }
  ];

  await Provider.insertMany(providers);
  console.log('Seed complete');
  process.exit(0);
}

seed().catch(e=>{ console.error(e); process.exit(1); });
