AI integration notes
--------------------
- To enable speech-to-text + LLM analysis, add either OPENAI_API_KEY or HUGGINGFACE_API_KEY to backend/.env.
- For OpenAI: ensure you have access to Whisper (audio transcription) and a chat-completion model.
- For Hugging Face: choose appropriate models for transcription and text generation. API shapes differ by model.
- This scaffold uses axios requests to provider endpoints; adapt model names and request bodies to your provider access.
