const fs = require("fs");
const axios = require("axios");
require("dotenv").config();

const OpenAI = require("openai");
const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

async function analyzeSymptoms(symptomsText) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return "⚠️ No OpenAI API key set. Please add it in backend/.env";
    }

    const response = await client.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a professional medical assistant. 
Always output the response as a structured report in Markdown with these sections:

# 🩺 Symptom Analysis Report  

### Possible Conditions  
(Numbered list with confidence levels and short explanations)  

### 🌸 First Aid Recommendations  
(Bulleted list of simple care steps)  

### 🚨 Red Flag Symptoms (Seek urgent care if these appear)  
(Bulleted list of serious warning signs)  

### 📝 Next Steps  
(Advice on monitoring, consulting a doctor, or telemedicine)  

### 📚 References  
(WHO, CDC, or credible links)`,
        },
        { role: "user", content: symptomsText },
      ],
      max_tokens: 700,
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error("Error in analyzeSymptoms:", error.message);

    return `
# 🩺 Symptom Analysis Report

### Possible Conditions
1. **Viral Infection** (High confidence)  
   - Common cause of fever  
   - Often with cough or sore throat  

2. **Bacterial Infection** (Moderate confidence)  
   - May need antibiotics if symptoms worsen  

3. **Heat Exhaustion** (Low confidence)  
   - Caused by dehydration and high temperature  

---

### 🌸 First Aid Recommendations
- Drink plenty of fluids  
- Rest in a cool place  
- Use a damp cloth on forehead  
- Monitor temperature regularly  

---

### 🚨 Red Flag Symptoms (Seek urgent care if these appear)
- Fever lasting > 3 days  
- Severe headache or stiff neck  
- Difficulty breathing  
- Persistent vomiting  
- Rash or unusual bruising  

---

### 📝 Next Steps
- Consult a doctor if symptoms persist  
- Try teleconsultation  
- Keep monitoring your temperature  

---

### 📚 References
- WHO – Fever Information  
- CDC – Fever FAQs  
    `;
  }
}

async function callWhisperOpenAI(filePath) {
  if (!process.env.OPENAI_API_KEY)
    throw new Error("OPENAI_API_KEY not set");

  const url = "https://api.openai.com/v1/audio/transcriptions";
  const FormData = require("form-data");
  const form = new FormData();
  form.append("file", fs.createReadStream(filePath));
  form.append("model", "whisper-1");

  const headers = {
    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    ...form.getHeaders(),
  };

  const resp = await axios.post(url, form, { headers });
  return resp.data.text || JSON.stringify(resp.data);
}

async function callWhisperHF(filePath) {
  if (!process.env.HUGGINGFACE_API_KEY)
    throw new Error("HUGGINGFACE_API_KEY not set");

  const url =
    "https://api-inference.huggingface.co/models/openai/whisper-large";
  const data = fs.readFileSync(filePath);

  const resp = await axios.post(url, data, {
    headers: {
      Authorization: `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
      "Content-Type": "audio/wav",
    },
  });

  return (
    resp.data?.text ||
    (typeof resp.data === "string" ? resp.data : JSON.stringify(resp.data))
  );
}

async function callLLMAnalysis(prompt) {
  if (process.env.OPENAI_API_KEY) {
    const url = "https://api.openai.com/v1/chat/completions";
    const payload = {
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a careful medical assistant providing non-diagnostic guidance. 
Always respond in the same structured Markdown report format:

# 🩺 Symptom Analysis Report  
### Possible Conditions  
### 🌸 First Aid Recommendations  
### 🚨 Red Flag Symptoms  
### 📝 Next Steps  
### 📚 References`,
        },
        { role: "user", content: prompt },
      ],
      max_tokens: 700,
    };

    const resp = await axios.post(url, payload, {
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
    });

    return (
      resp.data.choices?.[0]?.message?.content ?? JSON.stringify(resp.data)
    );
  }

  if (process.env.HUGGINGFACE_API_KEY) {
    const url =
      "https://api-inference.huggingface.co/models/google/flan-t5-large";
    const resp = await axios.post(
      url,
      { inputs: prompt },
      {
        headers: {
          Authorization: `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        },
      }
    );

    if (Array.isArray(resp.data) && resp.data[0].generated_text)
      return resp.data[0].generated_text;

    if (typeof resp.data === "string") return resp.data;

    return JSON.stringify(resp.data);
  }

  return "⚠️ No LLM provider configured. Please set OPENAI_API_KEY or HUGGINGFACE_API_KEY in backend/.env";
}

module.exports = {
  analyzeSymptoms,
  callWhisperOpenAI,
  callWhisperHF,
  callLLMAnalysis,
};
