const mongoose = require('mongoose')
const Schema = mongoose.Schema

const ProviderSchema = new Schema({
  name: String,
  type: String,
  address: String,
  languages: [String],
  phone: String,
  hours: String,
  coordinates: {lat:Number, lng:Number}
}, {timestamps:true})

module.exports = mongoose.model('Provider', ProviderSchema)
